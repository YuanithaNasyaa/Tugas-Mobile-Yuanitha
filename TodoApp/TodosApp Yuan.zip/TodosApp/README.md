# TodosApp (React Native + Expo + Firebase)

1. `npm install`
2. Isi konfigurasi Firebase di `config.js`.
3. Di Firebase Console, aktifkan Firestore Database dan buat collection `todos`
   (untuk uji coba, atur rules ke mode test).
4. `npx expo start`, lalu scan QR dengan Expo Go atau jalankan di emulator.

Bisa juga langsung ditempel ke Expo Snack (snack.expo.dev).
